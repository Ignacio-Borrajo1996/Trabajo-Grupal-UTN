using UnityEngine;
using UnityEngine.SceneManagement;

public class doorCode : MonoBehaviour
{
    [SerializeField] private GameObject player;


    // takes us into next level
    private void OnTriggerEnter2D(Collider2D other)
    {
        Debug.Log("Something entered trigger");


        if (other.gameObject == player)
        {
            Debug.Log("Player entered trigger");
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
        }
    }
}
